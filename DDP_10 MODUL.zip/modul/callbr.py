import bangunruang

print('## Kubus ##')

bangunruang.kubus(10)

print('## Balok ##')

bangunruang.balok(10, 15, 25)

print('## Tabung ##')

bangunruang.tabung(10, 15)

print('## Prisma ##')

bangunruang.prisma(10, 15, 20)

print('## Bola ##')

bangunruang.bola(17)