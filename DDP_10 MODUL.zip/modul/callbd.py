import bangundatar

print('## Persegi ##')

bangundatar.l_persegi(10)

print ('## Persegi Panjang ##')

bangundatar.persegi_panjang(5,4)

print ('## Segitiga ##')

bangundatar.segitiga(10, 15)

print ('## Lingkaran ##')

bangundatar.lingkaran(26)

print ('## Jajar Genjang ##')

bangundatar.jajar_genjang(10, 15)
