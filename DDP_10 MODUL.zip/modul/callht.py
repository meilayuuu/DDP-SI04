import hitung

print('## Pertambahan ##')

hitung.tambah(20, 33)

print('## Pergurangan ##')

hitung.kurang(48, 15)

print('## Perkalian ##')

hitung.kali(8, 15)

print('## Pembagian ##')

hitung.bagi(78, 2)

print('## Perpangkatan ##')

hitung.pangkat(5, 5)